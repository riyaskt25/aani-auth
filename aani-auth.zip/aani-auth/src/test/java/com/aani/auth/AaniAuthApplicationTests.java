package com.aani.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AaniAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
