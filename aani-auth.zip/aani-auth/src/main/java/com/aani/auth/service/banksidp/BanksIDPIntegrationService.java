package com.aani.auth.service.banksidp;

import com.aani.auth.dto.AuthoriseRequestDTO;
import com.aani.auth.dto.AuthoriseResponseDTO;
import com.aani.auth.dto.IdpAuthoriseRequestDTO;
import com.aani.auth.dto.IdpAuthoriseResponseDTO;

public interface BanksIDPIntegrationService {
	
	AuthoriseResponseDTO validate(AuthoriseRequestDTO authoriseRequestDTO);
	
	
	IdpAuthoriseResponseDTO authorize(IdpAuthoriseRequestDTO idpAuthoriseRequestDTO);

}
