package com.aani.auth.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.aani.auth.dto.LoginRequestDTO;
import com.aani.auth.dto.LoginResponseDTO;
import com.aani.auth.dto.URLRedirectionProperties;
import com.aani.auth.service.LoginService;
import com.aani.auth.util.AaniAuthUtil;

@Controller
public class LoginController {

	private static final Logger LOG = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private LoginService loginService;

	@PostMapping("/login")
	public String login(@ModelAttribute("loginDTO") LoginRequestDTO loginRequestDTO) {

		LOG.info("Starting login method execution..");

		LOG.debug("Parameter value available in login request are = {}", loginRequestDTO);

		LoginResponseDTO loginResponse = loginService.processLogin(loginRequestDTO);

		URLRedirectionProperties properties = URLRedirectionProperties.builder().redirectURL("aani://check-bank-sca")
				.code(loginResponse.getCode()).id_token(loginResponse.getIdentityToken()).state(loginResponse.getState())
				.build();

		String redirectURL = AaniAuthUtil.getRedirectURL(properties);

		return redirectURL;
	}

}