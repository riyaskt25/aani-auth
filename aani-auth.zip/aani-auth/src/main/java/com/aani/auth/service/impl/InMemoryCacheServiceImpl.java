package com.aani.auth.service.impl;

import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import com.aani.auth.dto.CachedParams;
import com.aani.auth.service.CacheService;

@Service
public class InMemoryCacheServiceImpl implements CacheService {

	private ConcurrentHashMap<String, CachedParams> cache = new ConcurrentHashMap<>();

	@Override
	public void put(String key, CachedParams params) {
		cache.put(key, params);

	}

	@Override
	public CachedParams get(String key) {
		return cache.get(key);
	}

}
