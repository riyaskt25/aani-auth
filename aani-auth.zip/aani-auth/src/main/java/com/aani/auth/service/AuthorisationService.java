package com.aani.auth.service;

import com.aani.auth.dto.AuthoriseRequestDTO;
import com.aani.auth.dto.AuthoriseResponseDTO;

public interface AuthorisationService {

	AuthoriseResponseDTO validate(AuthoriseRequestDTO dto);

}
