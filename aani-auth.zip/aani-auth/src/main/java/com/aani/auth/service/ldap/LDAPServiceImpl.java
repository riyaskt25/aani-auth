package com.aani.auth.service.ldap;

import org.springframework.stereotype.Service;

import com.aani.auth.dto.LoginRequestDTO;
import com.aani.auth.dto.LoginResponseDTO;

@Service
public class LDAPServiceImpl implements LDAPService {

	@Override
	public LoginResponseDTO authenticate(LoginRequestDTO dto) {
		return new LoginResponseDTO(Boolean.TRUE);
	}

}
