package com.aani.auth.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aani.auth.dto.CachedParams;
import com.aani.auth.dto.IdpAuthoriseRequestDTO;
import com.aani.auth.dto.IdpAuthoriseResponseDTO;
import com.aani.auth.dto.LoginRequestDTO;
import com.aani.auth.dto.LoginResponseDTO;
import com.aani.auth.service.CacheService;
import com.aani.auth.service.LoginService;
import com.aani.auth.service.banksidp.BanksIDPIntegrationService;
import com.aani.auth.service.ldap.LDAPService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LDAPService ldapService;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private BanksIDPIntegrationService banksIDPIntegrationService;

	@Override
	public LoginResponseDTO processLogin(LoginRequestDTO loginRequestDTO) {

		LoginResponseDTO loginResponseDTO = ldapService.authenticate(loginRequestDTO);

		// Get mobile phone number
		CachedParams cachedParams = cacheService.get("MOBILE_NUMBER");

		IdpAuthoriseRequestDTO idpAuthoriseRequestDTO = IdpAuthoriseRequestDTO.builder()
				.clientId(cachedParams.getClientId()).requestToken(cachedParams.getJwtToken())
				.redirectUri(cachedParams.getRedirectURI()).scope(cachedParams.getScope())
				.verificationCode(cachedParams.getVerificationCode()).build();

		IdpAuthoriseResponseDTO idpAuthoriseResponseDTO = banksIDPIntegrationService.authorize(idpAuthoriseRequestDTO);

		loginResponseDTO.setCode(idpAuthoriseResponseDTO.getCode());
		loginResponseDTO.setIdentityToken(idpAuthoriseResponseDTO.getIdentityToken());
		loginResponseDTO.setRedirectUri(idpAuthoriseResponseDTO.getRedirectUri());
		
		loginResponseDTO.setState(null);
		return loginResponseDTO;
	}

}
