package com.aani.auth.util;

import com.aani.auth.dto.URLRedirectionProperties;

public class AaniAuthUtil {

	private AaniAuthUtil() {

	}

	public static String SUCCESS = "SUCCESS";
	public static String FAILED = "FAILED";

	public static String getRedirectURL(URLRedirectionProperties properties) {

		StringBuilder sb = new StringBuilder("redirect:").append(properties.getRedirectURL()).append("?code=")
				.append(properties.getCode()).append("&id_token=").append(properties.getId_token())
				.append("&response_type=").append(properties.getResponse_type()).append("&state=")
				.append(properties.getState());
		return sb.toString();
	}
}
