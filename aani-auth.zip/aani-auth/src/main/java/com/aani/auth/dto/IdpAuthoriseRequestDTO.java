package com.aani.auth.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class IdpAuthoriseRequestDTO {

	private String clientId;

	private String requestToken;

	private String redirectUri;

	private String scope;

	private String verificationCode;
}
