package com.aani.auth.service.banksidp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.aani.auth.dto.AuthoriseRequestDTO;
import com.aani.auth.dto.AuthoriseResponseDTO;
import com.aani.auth.dto.IdpAuthoriseRequestDTO;
import com.aani.auth.dto.IdpAuthoriseResponseDTO;
import com.aani.auth.util.AaniAuthUtil;

@Service
public class BanksIDPIntegrationServiceImpl implements BanksIDPIntegrationService {

	private static final Logger LOG = LoggerFactory.getLogger(BanksIDPIntegrationServiceImpl.class);

	@Override
	public AuthoriseResponseDTO validate(AuthoriseRequestDTO authoriseRequestDTO) {

		LOG.info("Starting validate method execution with Banks IDP service..");
		// Connect with banks IDP service to validate the jwt token available in the
		// request
		String validationStatus = AaniAuthUtil.SUCCESS;
		if (authoriseRequestDTO.getState() != null && authoriseRequestDTO.getState().contains("abc")) {
			validationStatus = AaniAuthUtil.FAILED;
		}

		LOG.info("Validation status with Banks IDP service validationStatus={}", validationStatus);
		return AuthoriseResponseDTO.builder().status(validationStatus).build();
	}

	@Override
	public IdpAuthoriseResponseDTO authorize(IdpAuthoriseRequestDTO idpAuthoriseRequestDTO) {
		return IdpAuthoriseResponseDTO.builder().code("TEST_CODE").identityToken("TEST_ID_TOKEN")
				.redirectUri("TEST_RED_URI").build();
	}

}
