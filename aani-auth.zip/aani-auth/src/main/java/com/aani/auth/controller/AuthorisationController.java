package com.aani.auth.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.aani.auth.dto.AuthoriseRequestDTO;
import com.aani.auth.dto.AuthoriseResponseDTO;
import com.aani.auth.dto.URLRedirectionProperties;
import com.aani.auth.service.AuthorisationService;
import com.aani.auth.util.AaniAuthUtil;

@Controller
@RequestMapping("/")
public class AuthorisationController {

	private static final Logger LOG = LoggerFactory.getLogger(AuthorisationController.class);

	@Autowired
	private AuthorisationService authorisationService;

	@GetMapping("/authorise")
	public String authorise(AuthoriseRequestDTO authoriseRequestDTO) {

		LOG.info("Starting authorise method execution..");

		LOG.debug("Parameter value available in authorise request are = {}", authoriseRequestDTO);

		AuthoriseResponseDTO validationStatus = authorisationService.validate(authoriseRequestDTO);

		if (AaniAuthUtil.SUCCESS.equals(validationStatus.getStatus())) {
			// Login page will be displayed once after successful validation
			return "login";
		}

		URLRedirectionProperties properties = URLRedirectionProperties.builder().redirectURL("aani://check-bank-sca")
				.code("FAILED").id_token(authoriseRequestDTO.getRequest()).state(authoriseRequestDTO.getState())
				.build();

		String redirectURL = AaniAuthUtil.getRedirectURL(properties);

		return redirectURL;
	}

}
