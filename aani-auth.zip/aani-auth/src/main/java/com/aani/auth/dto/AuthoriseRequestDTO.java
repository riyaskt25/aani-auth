package com.aani.auth.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AuthoriseRequestDTO {

	private String client_id;

	private String request;

	private String response_type;

	private String redirect_uri;

	private String state;

	private String nonce;

	private String scope;

	private String prompt;

}