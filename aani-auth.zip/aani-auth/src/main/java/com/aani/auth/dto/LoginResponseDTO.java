package com.aani.auth.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginResponseDTO {

	boolean ldapAuthStatus = false;

	private String code;

	private String identityToken;

	private String redirectUri;
	
	private String state;

	public LoginResponseDTO(Boolean ldapAuthStatus) {
		this.ldapAuthStatus = ldapAuthStatus;
	}
}
