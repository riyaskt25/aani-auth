package com.aani.auth.service.ldap;

import com.aani.auth.dto.LoginRequestDTO;
import com.aani.auth.dto.LoginResponseDTO;

public interface LDAPService {

	LoginResponseDTO authenticate(LoginRequestDTO dto);

}
