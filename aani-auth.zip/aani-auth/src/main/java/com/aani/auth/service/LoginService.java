package com.aani.auth.service;

import com.aani.auth.dto.LoginRequestDTO;
import com.aani.auth.dto.LoginResponseDTO;

public interface LoginService {

	LoginResponseDTO processLogin(LoginRequestDTO loginRequestDTO);

}
