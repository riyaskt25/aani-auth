package com.aani.auth.service;

import com.aani.auth.dto.CachedParams;

public interface CacheService {

	void put(String key, CachedParams params);

	CachedParams get(String key);

}
