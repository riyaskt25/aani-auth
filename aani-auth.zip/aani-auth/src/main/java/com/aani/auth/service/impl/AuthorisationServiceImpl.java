package com.aani.auth.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aani.auth.dto.AuthoriseRequestDTO;
import com.aani.auth.dto.AuthoriseResponseDTO;
import com.aani.auth.dto.CachedParams;
import com.aani.auth.service.AuthorisationService;
import com.aani.auth.service.CacheService;
import com.aani.auth.service.banksidp.BanksIDPIntegrationService;
import com.aani.auth.util.AaniAuthUtil;

@Service
public class AuthorisationServiceImpl implements AuthorisationService {

	private static final Logger LOG = LoggerFactory.getLogger(AuthorisationServiceImpl.class);

	@Autowired
	private BanksIDPIntegrationService banksIdpService;

	@Autowired
	private CacheService cacheService;

	@Override
	public AuthoriseResponseDTO validate(AuthoriseRequestDTO authoriseRequestDTO) {

		LOG.info("Starting validate method execution..");

		LOG.debug("Parameter value available in authorise request are = {}", authoriseRequestDTO);

		// 1. Extract JWT token

		AuthoriseResponseDTO authoriseResponseDTO = banksIdpService.validate(authoriseRequestDTO);

		if (AaniAuthUtil.SUCCESS.equals(authoriseResponseDTO.getStatus())) {
			CachedParams cachedParams = CachedParams.builder().clientId(authoriseRequestDTO.getClient_id())
					.jwtToken(authoriseRequestDTO.getRequest()).redirectURI(authoriseRequestDTO.getRedirect_uri())
					.scope(authoriseRequestDTO.getScope()).verificationCode(authoriseResponseDTO.getVerificationCode())
					.build();
			cacheService.put("MOBILE_NUMBER", cachedParams);
			LOG.debug("Parameters saved to cache successfully cachedParams = {}", cachedParams);
		}

		return authoriseResponseDTO;
	}

}
